package a1_1901040249;

public class Match implements Comparable<Match> {
    private final Doc document;
    private final int firstIndex;
    private final Word matchWord;
    private int freq;

    public Match(Doc d, Word w, int freq, int firstIndex) {
        this.freq = freq;
        this.document = d;
        this.matchWord = w;
        this.firstIndex = firstIndex;
    }

    public int getFreq() {
        return freq;
    }

    public void setFreq(int newFreq) {
        this.freq = newFreq;
    }

    public int getFirstIndex() {
        return firstIndex;
    }

    public Word getWord() {
        return matchWord;
    }


    @Override
    public int compareTo(Match that) {
        int sub = firstIndex - that.firstIndex;
        return sub;
    }
}
