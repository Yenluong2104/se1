package a1_1901040249;

import java.util.*;

public class Doc {
    private final List<Word> listWordsTitle;
    private final List<Word> listWordsBody;
    private String docFileName;

    public Doc(String content) {
        String[] mLines = content.split("\n");
        String titleLine = mLines[0];
        String bodyLine = mLines[1];
        listWordsTitle = generateWordContent(titleLine);
        listWordsBody = generateWordContent(bodyLine);
    }


    public List<Word> getTitle() {
        return listWordsTitle;
    }

    public List<Word> getBody() {
        return listWordsBody;
    }

    public List<Word> generateWordContent(String rawText) {
        String[] mWords = rawText.split(" ");
        List<Word> words = new ArrayList<>();
        Iterator<String> wordIterator = Arrays.asList(mWords).iterator();
        while (wordIterator.hasNext()) {
            words.add(Word.createWord(wordIterator.next()));
        }
        return words;
    }

    @Override
    public boolean equals(Object anotherDoc) {
        if (this == anotherDoc) return true;
        if (anotherDoc == null
                || getClass() != anotherDoc.getClass())
            return false;
        Doc doc = (Doc) anotherDoc;
        return Objects.
                equals(listWordsTitle, doc.listWordsTitle) &&
                Objects.equals(listWordsBody, doc.listWordsBody);
    }

    public String getFileName() {
        return docFileName;
    }

    public void setFileName(String name) {
        this.docFileName = name;
    }
}
