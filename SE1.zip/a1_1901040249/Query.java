package a1_1901040249;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Query {
    private final String searchPhrase;

    public Query(String searchPhrase) {
        this.searchPhrase = searchPhrase;
    }


    public List<Word> getKeywords() {
        String[] searchWords = searchPhrase.split(" ");
        List<Word> wordRs = new ArrayList<>();
        Iterator<String> wordIterator = Arrays.asList(searchWords).iterator();
        while (wordIterator.hasNext()) {
            Word word = Word.createWord(wordIterator.next());
            if (word.isKeyword()) {
                wordRs.add(word);
            }
        }
        return wordRs;
    }

    public List<Match> matchAgainst(Doc d) {
        List<Match> listMatches = new ArrayList<>();

        List<Word> listKeyWords = getKeywords();
        List<Word> listDocWords = new ArrayList<>();
        listDocWords.addAll(d.getTitle());
        listDocWords.addAll(d.getBody());

        Iterator<Word> docWordIterator = listDocWords.iterator();
        int index = 0;
        while (docWordIterator.hasNext()) {
            Word w = docWordIterator.next();
            if (listKeyWords.contains(w)) {
                Match existedMatch = null;
                Iterator<Match> matchIterator = listMatches.iterator();
                while (matchIterator.hasNext()) {
                    Match m = matchIterator.next();
                    if (m.getWord().equals(w)) {
                        existedMatch = m;
                        break;
                    }
                }
                if (existedMatch == null) {
                    listMatches.add(new Match(d, w, 1, index));
                    continue;
                }
                existedMatch.setFreq(existedMatch.getFreq() + 1);
            }
            index++;
        }
        return listMatches;
    }
}
