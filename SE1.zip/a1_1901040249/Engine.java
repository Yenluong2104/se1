package a1_1901040249;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class Engine {
    private Doc[] docs;

    public int loadDocs(String docFolder) {
        File folderFile = new File(docFolder);
        File[] docFilesArray = folderFile.listFiles();
        assert docFilesArray != null;
        docs = new Doc[docFilesArray.length];
        int index = 0;
        Iterator<File> iterator = Arrays.asList(docFilesArray).iterator();
        while (iterator.hasNext()) {
            File file = iterator.next();
            try {
                StringBuilder mContent = new StringBuilder();
                RandomAccessFile rf = new RandomAccessFile(file, "rw");
                while (rf.getFilePointer() < rf.length()) {
                    String line = new String(rf.readLine().getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.UTF_8);
                    mContent.append(line).append("\n");
                }
                Doc newDoc = new Doc(mContent.toString());
                newDoc.setFileName(file.getName());
                docs[index] = newDoc;
                index++;
            } catch (Exception e) {
                //do nothing
            }
        }
        return docs.length;
    }


    public List<Result> search(Query q) {
        List<Result> listResults = new ArrayList<>();
        Iterator<Doc> iterator = Arrays.asList(docs).iterator();
        while (iterator.hasNext()) {
            Doc doc = iterator.next();
            Result rs = new Result(doc, q.matchAgainst(doc));
            if (rs.getMatches().size() > 0) {
                listResults.add(rs);
            }
        }
        Collections.sort(listResults);
        return listResults;
    }

    public Doc[] getDocs() {
        return docs;
    }

    public String htmlResult(List<Result> results) {
        StringBuilder resultString = new StringBuilder();
        Iterator<Result> iterator = results.iterator();
        while (iterator.hasNext()) {
            Result r = iterator.next();
            resultString.append(r.htmlHighlight());
        }
        return resultString.toString();
    }
}
