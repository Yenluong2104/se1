package a1_1901040249;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Word {
    public static Set<String> stopWords;
    private String rText;

    public static Word createWord(String rawText) {
        Word w = new Word();
        w.setInput(rawText);
        return w;
    }

    public static boolean loadStopWords(String path) {
        stopWords = new HashSet<>();
        try {
            File mf = new File(path);
            RandomAccessFile rd = new RandomAccessFile(mf, "r");
            while (rd.getFilePointer() < rd.length()) {
                String line = new String(rd.readLine().getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
                stopWords.add(line);
            }
            rd.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }


    public boolean isKeyword() {
        if (!isValid()) return false;
        Iterator<String> wordIterator = stopWords.iterator();
        while (wordIterator.hasNext()) {
            String w = wordIterator.next();
            if (w.equalsIgnoreCase(getText())) {
                return false;
            }
        }
        return true;
    }

    public boolean isValid() {
        if (rText != null
                && !rText.equals("")) {
            Matcher match = getMatcher("^[^a-zA-Z0-9 ]*[a-zA-Z'-]+([^a-zA-Z0-9 ]||'s)*$", rText);
            return match.find();
        }
        return false;
    }

    private void setInput(String rawText) {
        this.rText = rawText;
    }


    public String getText() {
        if (isValid()) {
            Matcher m = getMatcher("[a-zA-Z'-]+", rText);
            String realText = "";
            if (m.find()) {
                realText = m.group();
                if (realText.toUpperCase().endsWith("'S")) {
                    int index = realText.toUpperCase().lastIndexOf("'S");
                    realText = realText.substring(0, index);
                }
            }
            return realText;
        }
        return rText;
    }


    public String getPrefix() {
        if (isValid()) {
            Matcher match = getMatcher("^[^a-zA-Z0-9 ]*", rText);
            if (match.find()) {
                return match.group();
            }
        }
        return "";
    }

    public String getSuffix() {
        if (isValid()) {
            Matcher match = getMatcher("([^a-zA-Z0-9 ]||'s||'S)*$", rText);
            if (match.find()) {
                return match.group();
            }
        }
        return "";
    }


    private Matcher getMatcher(String pattern, String text) {
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(text);
        return m;
    }

    @Override
    public boolean equals(Object oWord) {
        if (this == oWord) return true;
        if (oWord == null || getClass() != oWord.getClass()) return false;
        Word word = (Word) oWord;
        return getText().equalsIgnoreCase(word.getText());
    }


    @Override
    public String toString() {
        return rText;
    }

}
