package a1_1901040249;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Result implements Comparable<Result> {
    private final Doc document;
    private final List<Match> listMatches;

    public Result(Doc d, List<Match> matches) {
        this.listMatches = matches;
        this.document = d;
    }

    public int getTotalFrequency() {
        int totalFreq = 0;
        Iterator<Match> iterator = listMatches.iterator();
        while (iterator.hasNext()) {
            Match m = iterator.next();
            totalFreq += m.getFreq();
        }
        return totalFreq;
    }

    public List<Match> getMatches() {
        return listMatches;
    }

    public double getAverageFirstIndex() {
        int averageIndexTotal = -1;
        if (listMatches.size() != 0)
            averageIndexTotal = 0;
        Iterator<Match> iterator = listMatches.iterator();
        while (iterator.hasNext()) {
            Match m = iterator.next();
            averageIndexTotal = averageIndexTotal + m.getFirstIndex();
        }
        float matchSize = (float) listMatches.size();
        return averageIndexTotal / matchSize;
    }

    public String htmlHighlight() {
        StringBuilder docHtml = new StringBuilder();
        List<Word> highLightWords = new ArrayList<>();

        Iterator<Match> matchIterator = listMatches.iterator();
        while (matchIterator.hasNext()) {
            Match m = matchIterator.next();
            highLightWords.add(m.getWord());
        }

        appendElement(
                docHtml,
                highLightWords, "u",
                document.getTitle(), "h3"
        );
        appendElement(
                docHtml,
                highLightWords, "b",
                document.getBody(), "p"
        );
        return docHtml.toString();
    }


    @Override
    public int compareTo(Result obj) {
        int o1MatchesSize = getMatches().size();
        int o2MatchesSize = obj.getMatches().size();
        if (o2MatchesSize != o1MatchesSize)
            return o2MatchesSize - o1MatchesSize;

        int o2TotalFrequency = obj.getTotalFrequency();
        if (o2TotalFrequency != getTotalFrequency())
            return o2TotalFrequency - getTotalFrequency();


        double diffIndex = getAverageFirstIndex() - obj.getAverageFirstIndex();
        if (diffIndex != 0)
            return (int) (diffIndex > 0 ?
                    Math.ceil(diffIndex) :
                    Math.floor(diffIndex));

        String o1FileName = document.getFileName();
        String o2FileName = obj.getDoc().getFileName();
        return o1FileName.compareTo(o2FileName);
    }


    public Doc getDoc() {
        return document;
    }

    private void appendElement(StringBuilder htmlRs, List<Word> highLightWord, String innerTag, List<Word> words, String outerTag) {
        htmlRs.append("<")
                .append(outerTag)
                .append(">");
        Iterator<Word> iterator = words.iterator();
        int i = 0;
        while (iterator.hasNext()) {
            Word w = iterator.next();
            String prefix = w.getPrefix();
            String realText = w.getText();
            String suffix = w.getSuffix();
            if (highLightWord.contains(w))
                htmlRs.append(prefix)
                        .append("<").append(innerTag).append(">")
                        .append(realText)
                        .append("</").append(innerTag).append(">")
                        .append(suffix);
            else htmlRs.append(w);
            if (i < words.size() - 1) {
                htmlRs.append(" ");
            }
            i++;
        }
        htmlRs.append("</").append(outerTag).append(">");
    }
}
